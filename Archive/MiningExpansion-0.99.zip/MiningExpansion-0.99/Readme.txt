OVERVIEW
===================================================================================================================
Stockalike Mining Extension 
This pack provides new stockalike ISRU and mining parts in a variety of formfactors.


INSTALLATION
===================================================================================================================
Place the GameData/MiningExpansion files into Kerbal Space Program/GameData. If installing SMX over a previous version, delete the previous version of SMX and then install.

Optional: If you don't want the Mk2 and 2.5m fuelcell to be able to use both FL/O and Ore, Install the Extras/multifuelcells.cfg into GameData/MiningExpansion/Patch/

Optional: If you want Eve's oceans to contain raw LiquidFuel instead of Ore, install the Extras/LiquidFuel.cfg and Extras/Ore.cfg into GameData/MiningExpansion/patch/ and overwrite the original Patch/Ore.cfg

If using Tweakscale, delete the Gamedata/TweakScale/patches/MiningEx_Tweakscale.cfg. It is out of date and may conflict with the TS patch included with SMX

LICENSE
===================================================================================================================
This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License(http://creativecommons.org/licenses/by-nc-sa/4.0/legalcode).

