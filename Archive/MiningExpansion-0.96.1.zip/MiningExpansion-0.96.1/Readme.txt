OVERVIEW
===================================================================================================================
Stockalike Mining Extension 
This pack provides new stockalike ISRU and mining parts in a variety of formfactors


INSTALLATION
===================================================================================================================
Place the GameData/MiningExpansion files into Kerbal Space Program/GameData. If installing SME over a previous version, delete the previous version of SME and then install 




LICENSE
===================================================================================================================
This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License(http://creativecommons.org/licenses/by-nc-sa/4.0/legalcode).

