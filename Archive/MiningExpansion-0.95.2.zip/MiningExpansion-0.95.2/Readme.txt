OVERVIEW
===================================================================================================================
Stockalike Mining Extension 
This pack provides new stockalike ISRU and mining parts in a variety of formfactors


INSTALLATION
===================================================================================================================
Place the GameData/MiningExpansion files into Kerbal Space Program/GameData. If installing SME over a previous version, delete the previous version of SME and then install SME 0.9

NOTE:if you have SME 0.8 installed, you will need to remove the following additional file: GameData/Mk2Expansion/parts/Resource; those parts have been split off and incorporated into MiningExtension. Not deleting these parts will result in duplicate parts in the VAB/SPH.



LICENSE
===================================================================================================================
This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License(http://creativecommons.org/licenses/by-nc-sa/4.0/legalcode).

